/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiceProject;

import java.util.Arrays;
import java.util.Scanner;

public class DiceGame {

    private static int[] getCounts(int[] dice) {
        int oneCount = 0;
        int[] count = new int[6];
        for (int i = 0; i < count.length; i++) {
            count[i] = 0;
        }
        for (int i = 0; i < dice.length; i++) {
            if (dice[i] == 1) {
                oneCount++;
            }
        }
        count[0] = oneCount;
        int twoCount = 0;
        for (int i = 0; i < dice.length; i++) {
            if (dice[i] == 2) {
                twoCount++;
            }
        }
        count[1] = twoCount;
        int threeCount = 0;
        for (int i = 0; i < dice.length; i++) {
            if (dice[i] == 3) {
                threeCount++;
            }
        }
        count[2] = threeCount;
        int fourCount = 0;
        for (int i = 0; i < dice.length; i++) {
            if (dice[i] == 4) {
                fourCount++;
            }
        }
        count[3] = fourCount;
        int fiveCount = 0;
        for (int i = 0; i < dice.length; i++) {
            if (dice[i] == 5) {
                fiveCount++;
            }
        }
        count[4] = fiveCount;
        int sixCount = 0;
        for (int i = 0; i < dice.length; i++) {
            if (dice[i] == 6) {
                sixCount++;
            }
        }
        count[5] = sixCount;
        return count;
    }


    private static String getResult(int[] dice) {
        String hand = "";
        int[] count = getCounts(dice);
        int twoCounter = 0;
        Arrays.sort(dice);
        int index = 0;
        for (int i = 0; i < count.length; i++) {
            if (count[i] == 2) {
                twoCounter++;
            }
            if (twoCounter == 1) {
                if (index == 0) {
                    hand = "one," + (i + 1);
                    index = 1;
                }
            }
            if (twoCounter == 2) {
                hand = "two," + (i + 1);
                break;
            }
        }
        int threeCounter = 0;
        index = 0;
        for (int i = 0; i < count.length; i++) {
            if (count[i] == 3) {
                threeCounter++;
                index = i + 1;
            }
        }
        if (threeCounter == 1) {
            hand = "three," + index;
        }
        if (threeCounter == 1 && twoCounter == 1) {
            hand = "full,0";
        }
        int fourCounter = 0;
        index = 0;
        for (int i = 0; i < count.length; i++) {
            if (count[i] == 4) {
                fourCounter++;
            }
            if (fourCounter == 1) {
                hand = "four," + i;
            }
        }
        int fiveCounter = 0;
        index = 0;
        for (int i = 0; i < count.length; i++) {
            if (count[i] == 5) {
                fiveCounter++;
            }
            if (fiveCounter == 1) {
                hand = "five," + i;
            }
        }
        int prev = -1;
        int flag = 0;    
        for (int i = 0; i < dice.length; i++) {
            if (prev == -1 || (prev + 1) == dice[i]) {
                prev = dice[i];
            } else {
                flag = 1;
            }
        }
        if (flag == 0) {
            hand = "straight,0";
        }
        int highest = 0;
        if (hand.equals("")) {
            for (int i = 0; i < dice.length; i++) {
                if (dice[i] > highest) {
                    highest = dice[i];
                }
            }
            hand = "highest," + highest;
        }
        return hand;
    }


    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        int numPlayers = 0;
        int numSides = 0;
        int numPoints = 0;
        do {
            System.out.print("Enter number of players (2 to 4): ");
            numPlayers = Integer.parseInt(reader.nextLine());
            if (numPlayers >= 2 && numPlayers <= 4) {
                break;
            } else {
                System.out.println("Invalid number.");
            }
        } while (true);
//        System.out.print("Enter number of sides: ");
        numSides = 5;
//Integer.parseInt(reader.nextLine());
        Dice[] playerDice = new Dice[numPlayers];
        String[][] playerHand = new String[numPlayers][2];
        int[] highHand = new int[numPlayers];
        int[] playerScore = new int[numPlayers];
        for (int i = 0; i < numPlayers; i++) {
            playerDice[i] = new Dice();
        }
        do{
//            System.out.print("Ente number of points: ");
            numPoints = 50;
//                    Integer.parseInt(reader.nextLine());
            if(numPoints>=50){
                break;
            }else{
                System.out.println("Invalid number of points.");
            }
        }while(true);
        
        while(true) {
            System.out.println("======================================================");
            for (int i = 0; i < numPlayers; i++) {
                playerHand[i] = getResult(playerDice[i].diceroll()).split(",");
                System.out.println("Player #" + (i + 1) + " rolls: " + playerDice[i].toString());
                switch (playerHand[i][0]) {
                    case "one":
                        highHand[i] = 2;
                        System.out.println("One Pair!");
                        break;
                    case "two":
                        highHand[i] = 3;
                        System.out.println("Two Pairs!");
                        break;
                    case "three":
                        highHand[i] = 4;
                        System.out.println("Thriple!");
                        break;
                    case "full":
                        highHand[i] = 5;
                        System.out.println("triple+pair");
                        break;
                    case "four":
                        highHand[i] = 6;
                        System.out.println("Four same ");
                        break;
                    case "five":
                        highHand[i] = 8;
                        System.out.println("Quint!");
                        break;
                    case "straight":
                        highHand[i] = 7;
                        System.out.println("Straight!");
                        break;
                    case "highest":
                        highHand[i] = 1;
                        System.out.println("highest: " + playerHand[i][1]);
                }
                System.out.println("------------------------------------------------------");
            }
            int index = 0;
            int max = highHand[0];
            int higherDie = Integer.parseInt(playerHand[0][1]);
            for (int i = 1; i < numPlayers; i++) {
                if (max < highHand[i]) {
                    index = i;
                    max = highHand[i];
                    higherDie = Integer.parseInt(playerHand[i][1]);
                } else if (max == highHand[i]) {
                    if (higherDie < Integer.parseInt(playerHand[i][1])) {
                        index = i;
                        max = highHand[i];
                        higherDie = Integer.parseInt(playerHand[i][1]);


                    }
                }
            }
            playerScore[index] += highHand[index];
            System.out.println("player #" + (index + 1) + " wins.");
            System.out.println("======================================================");
            System.out.println("Scores: ");
            for (int i = 0; i < numPlayers; i++) {
                System.out.println("Player #" + (i + 1) + ": " + playerScore[i]);
            }
            System.out.println("*******************************************************");
            if(playerScore[index]>=numPoints){
                break;
            }
        }
    }
}

/**
 *
 * @author Admin
 */
//public class DiceGame {
    
//   ArrayList <Die> playerNumber ;
//   
//      public int []rollResult(){
//         
//      int Dno;
//    String dname;
//    
//   
//    public DiceGame(int Dno, String dname, ArrayList<Die> emplist) {
//        this.Dno = Dno;
//        this.dname = dname;
//        this.playerNumber = emplist;
//    }
//
//    public int getDno() {
//        return Dno;
//    }
//
//    public void setDno(int Dno) {
//        this.Dno = Dno;
//    }
//
//    public String getDname() {
//        return dname;
//    }
//
//    public void setDname(String dname) {
//        this.dname = dname;
//    }
//
//public void add_playerName(Dice n){
//    
//    playerNumber.add(n);
//     
//          
//          
//          
//          
//          
//          
//      }
//          
//          
    
          
//        
//      int result[] = null;
//  
//          Dice[][] players= new Dice[5][4];
//   
//       
//    for( int i=0; i<players.length; i++ )
//    {
//        for(int j=0;j<players.length;j++)
//               
//   {
//       result=players[i][j].diceroll();
//  }    
//         
    
 
          
//      }
//          return result;
//}
//}
//    int[] players= new int[4];
//    
//    
//    public int []rollResult(){
//        
//   int result[] = null;
//   
//        
//    for( int i=0; i<players.length; i++ )
//    {
//         System.out.println("the rol numbers are"+players.get(i).diceroll()+
//                players.get(i).sumDice());
//    }
////    for(int i=0; i<MAXdice; i++)
////    {
////        System.out.print(mydice[i]+ ", ");
////    }
//    return result;
    
    
    
    

    
    
    
    
    
    
    
    
    

////      int[] players= new int[4];
//        ArrayList <Dice> playerNumber ;
//        
//        
//      public int[] four_playerroll(){
//          
//     for(int i=1;i<=4;i++)
//     {
//           int[] total;
//         
//          
//         System.out.println("the rol numbers are"+playerNumber.get(i).diceroll()+
//                 playerNumber.get(i).sumDice());
//         
//             total[i]=playerNumber.get(i).nSpecial(i);
//         
//     
//            return total;
//      
//}
//     
//      }
//     public int[] matching(){
//         
//     
//         int [] result=new int[0];
//        
//         for(int i=1;i<=4;i++){
//             System.out.println("the matching dice"+playerNumber.get(i).nSpecial(i));
//     
//            result[i]=playerNumber.get(i).nSpecial(i);
//
//
//      }
//            return result;
//}
//}
     //    
//     public void four_player(){
//     for(int i=1;i<4;i++){
//         if (playerNumber.get(i) instanceof Dice)
//         ((Dice) playerNumber.get(i)).toString();
//     }
//     }
//
//  
//}
//   
//}
//    
//}
