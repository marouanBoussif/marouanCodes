/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiceProject;

import java.util.Random;
/**
 *
 * @author AYOUB
 */
public class Die {
    
    public int numSides=6;
    protected int minNum=1;

    public Die() {
    }
    
    
    public int roll()
    {
        
      
       int  rollNum =(int) ( Math.random() * (numSides - minNum + 1) + minNum);
       
       return rollNum ;
    }

    @Override
    public String toString() {
        return "Die{" + "numSides=" + numSides + '}';
    }
    
}
