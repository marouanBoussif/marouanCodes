/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiceProject;

/**
 *
 * @author Admin
 */
public class TesTDie {
     public static void main(String[] args) {
        Die die1 = new Die();
        Die die2 = new Die();
        System.out.println(die1.toString());
        System.out.println(die2.toString());
    
}
}
