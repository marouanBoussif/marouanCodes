/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiceProject;

import java.util.ArrayList;
import java.util.Arrays;


/**
 *
 * @author AYOUB
 */
public class Test  {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
//        int players1 [];
//         int players2 [];
//                  int players3 [];
//                           int players4 [];
        
     int [] players=new int [5];
     for(int i=1;i<players.length;i++){
        System.out.println( "player number: "+i );
        Pair player= new Pair();
        System.out.println(""+Arrays.toString(player.diceroll())); 
        System.out.println("this is the sum:  "+player.sumDice());
         System.out.println(""+player.isDoubles());
         System.out.println(""+player.isSnakeEes());
         System.out.println(""+player.isSixth());
     }
    
// Start
   int size= 5; 
    Pair player= new Pair();
 int[] playerx=new int[size];
 int score1=0;
 int score2=0;
 int score3=0;
 int score4=0;
 int score5=0;
 int score6=0;
 int countPairs=0;
 int countTrip=0;
 int x=-1;
for(int i=0; i<4;i++)
{
   playerx= player.diceroll();
   int[] scoreArray=new int[5];
   for(int j=0; j<scoreArray.length;j++)
   {
       if(playerx[j]==1)
           score1++;
       scoreArray[0]=score1;
       if(playerx[j]==2)
           score2++;
        scoreArray[1]=score2;
       if(playerx[j]==3)
           score3++;
       scoreArray[2]=score3;
       if(playerx[j]==4)
           score4++;
       scoreArray[3]=score4;
       if(playerx[j]==5)
           score5++;
       scoreArray[4]=score5;
       if(playerx[j]==6)
           score6++;
       scoreArray[5]=score6;
   }
   
   for(int score=1;score<scoreArray.length+1; score++)
   
   {
       int Pair,triple,twoPr,trip_pair,quad,straight,quint;
       
       if(scoreArray[score]==2 )
       {
        Pair=2;
        countPairs++;
       }
       else if (scoreArray[score]==3)
       {
        triple=4;
       countTrip++;
       }
       else if(countPairs==2)
          twoPr=3;
       else  if((countPairs==1)&& (countTrip==1))
        trip_pair=5;
         else  if(scoreArray[score]==4 )
        quad=6;
          else  if(scoreArray[score]==5 )
        quint=8;
  
        else if ((x==-1)||(x+1)==scoreArray[score]){
              
          x=scoreArray[score];
          straight=7;
          }
       
            
                  
       
       
       
           
   }
   
   

       
       
       
   
   

}   
    }



















//        int oneCount=0;
//       int [] count= new int[6];
//       for(i=0;i<count.length;i++){
//           count[i]=0;
//       }
//        
//       for(i=0;i<players.length;i++){
//           if (players[i]==1){
//               oneCount++;
//           }
//           count[0]=oneCount;
//               int twoCount=0;
//            if (players[i]== 2) {
//                twoCount++;
//            }
//        count[1] = twoCount;
// 
//              int threeCount = 0;
//            if (players[i] == 3) {
//                threeCount++;
//            }
//        
//        count[2] = threeCount;
//        int fourCount = 0;
//        
//            if (players[i] == 4) {
//                fourCount++;
//            }
//        
//        count[3] = fourCount;
//        int fiveCount = 0;
//        
//            if (players[i] == 5) {
//                fiveCount++;
//            }
//        
//        count[4] = fiveCount;
//        int sixCount = 0;
//        
//            if (players[i] == 6) {
//                sixCount++;
//            
//            }
//        count[5] = sixCount;
//       }
//    }

      

   
        
    
//      
//        Dice[] players= new Dice[5];
//         for( int i=0; i<players.length; i++ ){
//             
//             players[i].diceroll();
//             System.out.println(""+Arrays.toString(players[i].diceroll()));
//        
//   
//          for( int i=0; i<players.length; i++ )
//  {
//      for(int j=0;j<players.length;j++)
//                {
//          int[] result = players[i][j].diceroll();
//          
//                    System.out.println("tru"+Arrays.toString(result));
        
            
        
        
    
   
//    public void testarray( int[] myarray)
//    {
//        Pair player1 = new Pair();
//        
//        player1.diceroll();
//        
//    }
         
            

//        Die mydie = new Die();
//       System.out.println(mydie.roll());
//       
//       
//     Dice players=new Dice ();
//       
//        System.out.println(Arrays.toString(players.diceroll()));
//       Pair ayoub=new Pair();
//        System.out.println(""+Arrays.toString(ayoub.diceroll())+ayoub.isDoubles()+ayoub.isSixth()+ayoub.isSnakeEes());
////      Dice[] players= new Dice[5];
//               Dice [] players= new Dice[5] ; 
//         for(int i=0;i>players.length;i++)
        
//        System.out.println(players[].sumDice());
//        for(int i=0;i>players.length;i++)
//        
        
   

      //     Dice game= new Dice() ; 
//        Die mydie = new Die();
       // System.out.println(mydie.roll());
       
        
//      Dice printdice = new Dice();
        
     //System.out.println(Arrays.toString(printdice.diceroll()));
  
      //System.out.println((printdice.sumDice()));  
      
//      System.out.println((printdice.nSpecial(1)));  
//     DiceGame Game = new DiceGame();
//        System.out.println(""+Arrays.toString(Game.rollResult()));
       

   