/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiceProject;

/**
 *
 * @author AYOUB
 */
public class Pair extends Dice {
    
boolean isSnakeEes(){
    
    Dice mb=new Dice();
    int [] storeArray =Dice.getMyarr();
    System.out.println("dice number one=  "+storeArray[0]+", dice number two=  "+storeArray[1]);//this pair
    return (storeArray[0]==1)&&(storeArray[1]==1);
}

boolean isDoubles(){
    
  Dice mb=new Dice();
    int [] storeArray =Dice.getMyarr();
    System.out.println("dice number one=  "+storeArray[0]+", dice number two=  "+storeArray[1]);//this double
    return storeArray[0]==storeArray[1] ;
            }
boolean isSixth(){
     Dice mb=new Dice();
    int [] storeArray =Dice.getMyarr();
    System.out.println("dice number one=  "+storeArray[0]+", dice number two=   "+storeArray[1]);// sixth
    return storeArray[0]==6 &&  storeArray[1]==6 ;
    
}

    @Override
    public String toString() {
        return "";
    }


}
