/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiceProject;

/**
 *
 * @author Admin
 */
public class TesTPair {
 public static void main(String[] args) {
        Pair dice = new Pair();
        dice.diceroll();
        System.out.println(dice.toString());
        System.out.println("Is Doubles: " + dice.isDoubles());
        System.out.println("Is Snake Eyes: " + dice.isSnakeEes());
        System.out.println("Is Sixes: " + dice.isSixth());
 }
}