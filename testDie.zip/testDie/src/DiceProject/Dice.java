/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiceProject;

import java.util.Arrays;


/**
 *
 * @author AYOUB
 */
public class  Dice extends Die
{
    
   protected int  MAXdice=5;
   protected  int  numDice=5;
  static int[]myarr;


    
    
   Die[] dice= new Die[MAXdice];// to initilize dice array with Die class
    
    // diceroll method created to store the random values we get from die class 
    //and return them in antiher array called mydice

   
    public int[] diceroll( ) 
    {
    int[] mydice= new int[numDice]; // to store the  random dice values.

    for( int i=0; i<mydice.length; i++ )
    {
      dice[i]= new Die();
      mydice[i]= dice[i].roll();
    }
//    for(int i=0; i<MAXdice; i++)
//    {
//        System.out.print(mydice[i]+ ", ");
//    }
    myarr=mydice;
    return mydice;
    }
    
    public  static int[] getMyarr() {
        return myarr;
    }
    
   public int sumDice(  )
   {
       int sum=0;
      int newarr[];
      newarr=myarr;
      
      for(int i=0; i<MAXdice; i++)
      {
          sum+=newarr[i];
      }
       return sum;
   }
   
   public int nSpecial(int partNum) {
    int[] arr;
    int count = 0;
    arr= myarr;  
      for(int i=0; i<MAXdice; i++)
    {
        System.out.print(arr[i]+ ", ");
    }
       System.out.println("\n");
    for(int i=0; i<MAXdice; i++) {
        {
            if(partNum==arr[i]) 
            {
                count ++;// to count the number matched
            }
        }   
    }
    
        //System.out.println("this my array " + Arrays.toString(arr));
        //System.out.println("this is matched num:" + matchedNumIndex);
        return count;
   }

    @Override
    public String toString() {
        return "Dice{" + "MAXdice=" + MAXdice + ", numDice=" + numDice + ", dice=" + Arrays.toString(myarr) + '}';
    }

    

}
    
    
 
   
    

