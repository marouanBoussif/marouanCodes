/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiceProject;

/**
 *
 * @author Admin
 */
public class TestDice {
    
    public static void main(String[] args) {
        Dice dice = new Dice();     
        dice.diceroll();
        System.out.println(dice.toString());
        System.out.println("Sum: " +dice.sumDice());
        System.out.println("Count of 5's: " +dice.nSpecial(6));
   
    
}
}
